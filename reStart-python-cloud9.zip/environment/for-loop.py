# for-loop.py
# Lab: Working with a for loop

print("Count to 10!")

# range(0, 11) = mulai dari 0 sampai 10
for x in range(0, 11):
    print(x)
